import glob
import pandas as pd
import csv
import os
from parser_sql.parse_sql_one import get_schema, Schema, get_sql, get_schema_from_json
DISABLE_VALUE = True
# Flag to disable distinct in select evaluation
DISABLE_DISTINCT = True


CLAUSE_KEYWORDS = (
    "select",
    "from",
    "where",
    "group",
    "order",
    "limit",
    "intersect",
    "union",
    "except",
)
JOIN_KEYWORDS = ("join", "on", "as")

WHERE_OPS = (
    "not",
    "between",
    "=",
    ">",
    "<",
    ">=",
    "<=",
    "!=",
    "in",
    "like",
    "is",
    "exists",
)
UNIT_OPS = ("none", "-", "+", "*", "/")
AGG_OPS = ("none", "max", "min", "count", "sum", "avg")
TABLE_TYPE = {
    "sql": "sql",
    "table_unit": "table_unit",
}

COND_OPS = ("and", "or")
SQL_OPS = ("intersect", "union", "except")
ORDER_OPS = ("desc", "asc")


HARDNESS = {
    "component1": ("where", "group", "order", "limit", "join", "or", "like"),
    "component2": ("except", "union", "intersect"),
}

def condition_has_or(conds):
    return "or" in conds[1::2]


def condition_has_like(conds):
    return WHERE_OPS.index("like") in [cond_unit[1] for cond_unit in conds[::2]]


def condition_has_sql(conds):
    for cond_unit in conds[::2]:
        val1, val2 = cond_unit[3], cond_unit[4]
        if val1 is not None and type(val1) is dict:
            return True
        if val2 is not None and type(val2) is dict:
            return True
    return False


def val_has_op(val_unit):
    return val_unit[0] != UNIT_OPS.index("none")


def get_nestedSQL(sql):
    nested = []
    for cond_unit in sql["from"]["conds"][::2] + sql["where"][::2] + sql["having"][::2]:
        if type(cond_unit[3]) is dict:
            nested.append(cond_unit[3])
        if type(cond_unit[4]) is dict:
            nested.append(cond_unit[4])
    if sql["intersect"] is not None:
        nested.append(sql["intersect"])
    if sql["except"] is not None:
        nested.append(sql["except"])
    if sql["union"] is not None:
        nested.append(sql["union"])
    return nested


def has_agg(unit):
    return unit[0] != AGG_OPS.index("none")



def count_agg(units):
    return len([unit for unit in units if has_agg(unit)])


def count_component1(sql):
    count = 0
    if len(sql["where"]) > 0:
        count += 1
    if len(sql["groupBy"]) > 0:
        count += 1
    if len(sql["orderBy"]) > 0:
        count += 1
    if sql["limit"] is not None:
        count += 1
    if len(sql["from"]["table_units"]) > 0:  # JOIN
        count += len(sql["from"]["table_units"]) - 1

    ao = sql["from"]["conds"][1::2] + sql["where"][1::2] + sql["having"][1::2]
    count += len([token for token in ao if token == "or"])
    cond_units = sql["from"]["conds"][::2] + sql["where"][::2] + sql["having"][::2]
  
    count += len(
        [
            cond_unit
            for cond_unit in cond_units
            if cond_unit[1] == WHERE_OPS.index("like")
        ]
    )

    return count


def count_component2(sql):
    nested = get_nestedSQL(sql)
    return len(nested)


def count_others(sql):
    count = 0
    # number of aggregation
    agg_count = count_agg(sql["select"][1])
    agg_count += count_agg(sql["where"][::2])
    agg_count += count_agg(sql["groupBy"])
    if len(sql["orderBy"]) > 0:
        agg_count += count_agg(
            [unit[1] for unit in sql["orderBy"][1] if unit[1]]
            + [unit[2] for unit in sql["orderBy"][1] if unit[2]]
        )
    agg_count += count_agg(sql["having"])
    if agg_count > 1:
        count += 1

    # number of select columns
    if len(sql["select"][1]) > 1:
        count += 1

    # number of where conditions
    if len(sql["where"]) > 1:
        count += 1

    # number of group by clauses
    if len(sql["groupBy"]) > 1:
        count += 1

    return count

class Evaluator:
    """A simple evaluator"""

    def __init__(self):
        self.partial_scores = None

    def eval_hardness(self, sql):
        count_comp1_ = count_component1(sql)
        # print(count_comp1_)
        count_comp2_ = count_component2(sql)
        # print(count_comp2_)
        count_others_ = count_others(sql)
        # print(count_others_)

        if count_comp1_ <= 1 and count_others_ == 0 and count_comp2_ == 0:
            return "easy"
        elif (count_others_ <= 2 and count_comp1_ <= 1 and count_comp2_ == 0) or (
            count_comp1_ <= 2 and count_others_ < 2 and count_comp2_ == 0
        ):
            return "medium"
        elif (
            (count_others_ > 2 and count_comp1_ <= 2 and count_comp2_ == 0)
            or (2 < count_comp1_ <= 3 and count_others_ <= 2 and count_comp2_ == 0)
            or (count_comp1_ <= 1 and count_others_ == 0 and count_comp2_ <= 1)
        ):
            return "hard"
        else:
            return "extra"

def concat_all(folder_path):
    combined_df = pd.DataFrame()

# Loop through all CSV files in the folder
    for file_path in glob.glob(os.path.join(folder_path, '*.csv')):
        # Read the current CSV file
        df = pd.read_csv(file_path)
        
        # Extract the file name without extension to use as the db name
        db_name = os.path.basename(file_path).replace('.csv', '').split("_res")[0]
        
        # Add a new column with the db name
        df['db_name'] = db_name
        
        # Append the data to the combined DataFrame
        combined_df = pd.concat([combined_df, df], ignore_index=True)

    # Save the combined data to a new CSV file (optional)
    combined_df.to_csv('data/synthetic-queries/Rule-based/rule-based-synthsql.csv', index=False)

    # Display the combined data
    # combined_df.head()

def calculate_statistics(data):
    averages = {}
    total_counts = {key: 0 for key in data[next(iter(data))]}  # Initialize with keys from the first item
    total_sums = {key: 0 for key in total_counts}

    # Calculate sums and counts for averages
    for subdict in data.values():
        for key, value in subdict.items():
            total_sums[key] += value
            total_counts[key] += 1

    # Calculate averages
    for key in total_sums:
        averages[key] = total_sums[key] / total_counts[key]

    return averages



statistics = {}
hardness_levels = {"easy":0, "medium":0, "hard":0, "extra":0, "table_1":0, "table_2":0, "table_3":0, "table_4":0,"nested":0, 'all':0}
if __name__ == "__main__":
    folder_path = "data/synthetic-queries/Rule-based/"
    # concat_all(folder_path)
    # file = "data/synthetic-queries/Rule-based/rule-based-synthsql.csv"
    evaluator = Evaluator()

    for file in glob.glob(os.path.join(folder_path, '*.csv')):
         

        db_name = os.path.basename(file).split("_res.csv")[0]

        statistics[db_name] = hardness_levels.copy()
        df = pd.read_csv(file)
        for instance in df.to_dict(orient="records"):
  

            db2 = os.path.join("test-suite-sql-eval-master/database/", db_name, db_name + ".sqlite")
            # print(db2)
            schema2 = Schema(get_schema(db2))

            query = instance["query"]
            # print("query:",query)
            
            g_sql = get_sql(schema2, query=query)
            count_table = len(g_sql["from"]["table_units"])

            # print(get_nestedSQL(g_sql)) 
                
            hardness = evaluator.eval_hardness(g_sql)
            statistics[db_name][hardness] += 1
            statistics[db_name]["table_" + str(count_table)] += 1
            statistics[db_name]["all"] += 1
            statistics[db_name]["nested"] += 1 if count_component2(g_sql) > 0 else 0


           
#     print(statistics)
#     # Define the dataset statistics


# # Calculate total and average statistics across all categories
    summary_stats = {
    'easy': 0,
    'medium': 0,
    'hard': 0,
    'extra': 0,
    'table_1': 0,
    'table_2': 0,
    'table_3': 0,
    'table_4': 0,
    'nested': 0,
    'all': 0
}

    for stats in statistics.values():
        for key in summary_stats.keys():
            summary_stats[key] += stats.get(key, 0)
    count = len(statistics)

    # Print summary results
    print("Total Statistics:", summary_stats)
    # Get averages and print them
    averages = calculate_statistics(statistics)
    print("Averages for each category:")
    for key, avg in averages.items():
        print(f"{key}: {avg:.2f}")
    with open('outputs/experiments/SyntheticBenchmarkEvaluation/rule_based/overview.txt', 'w') as file:
        for key, avg in averages.items():
            file.write(f"{key}: {avg:.2f}\n")
    with open('outputs/experiments/SyntheticBenchmarkEvaluation/rule_based/overview.txt', 'a') as file:
        file.write(f"Total Statistics: {summary_stats}\n")

    
            
        