import csv
import json
import os
import random

from openai import OpenAI
from json_repair import repair_json
# Import functions from different modules
from group_by_having import complete_with_group_by_clause
from having import complete_with_having_clause
from helper_funcs import print_attributes, write_queries_to_file
from limit import complete_query_with_limit
from order_by import complete_query_with_order_by
from parser_sql.parse_sql_one import   get_sql, get_schema
from read_schema import read_schema_pk_fk_types
from read_schema.read_schema import convert_json_to_schema
from select_query import complete_query_with_select
from specification_generator_using_ht import complete_specs

from table_expression import create_table_expression
from where import complete_with_where_clause
import glob
import pandas as pd
class Schema3:
    """
    Simple schema which maps table&column to a unique identifier
    """
    def __init__(self, schema):
        self._schema = schema
        self._idMap = self._map(self._schema)

    @property
    def schema(self):
        return self._schema

    @property
    def idMap(self):
        return self._idMap

    def _map(self, schema):
        idMap = {'*': "__all__"}
        id = 1
        for key, vals in schema.items():
            for val in vals:
                idMap[key.lower() + "." + val.lower()] = "__" + key.lower() + "." + val.lower() + "__"
                id += 1

        for key in schema:
            idMap[key.lower()] = "__" + key.lower() + "__"
            id += 1

        return idMap

def query_generator_single_schema(
    db_name,
    schema,
    pk,
    fk,
    schema_types,
    specs=None,
    max_num=1000,
    must_be_in_select=None,
    must_be_in_where=None,
    write_to_csv=True,
    is_subquery=False,
    random_choice=False,
    return_select_fields=False,
    return_table_exp_attributes=False,
    return_unique_tables=False,
    return_select_fields_dict=False,
    for_cte=None,
    rename_must_be_in_select=False,
):
    """
    Generate queries based on the specifications provided in the specs dictionary.

    Args:
        db_name (str): The name of the database.
        schema (dict): The schema of the database.
        pk (list): The primary key columns.
        fk (list): The foreign key columns.
        schema_types (dict): The data types of the schema.
        specs (dict, optional): The specifications for generating queries. Defaults to None.
        max_num (int, optional): The maximum number of queries to generate. Defaults to 1000.
        must_be_in_select (list, optional): The attributes that must be included in the SELECT clause. Defaults to None.
        must_be_in_where (list, optional): The attributes that must be included in the WHERE clause. Defaults to None.
        write_to_csv (bool, optional): Whether to write the generated queries to a CSV file. Defaults to True.
        is_subquery (bool, optional): Whether the generated queries are subqueries. Defaults to False.
        random_choice (bool, optional): Whether to use random choice for certain query components. Defaults to False.

    Returns:
        dict: A dictionary containing the generated queries.
    """
    print("Start reading specifications")
    testing_with_one_spec = False
    if specs is not None:
        testing_with_one_spec = True
    if not testing_with_one_spec:
        print("Testing with multiple specifications")
        current_dir = os.path.dirname(__file__)
        file_name = os.path.join(current_dir, f"output/specs/{db_name}.json")
        with open(file_name) as json_file:
            specs = json.load(json_file)
    else:
        print("Testing with one specification")
        print(specs)

    print("Start generating queries")
    merged_queries = {}
    return_select_fields_dict = {}
    schema_copy = schema.copy()
    pk_copy = pk.copy()
    fk_copy = fk.copy()
    schema_types_copy = schema_types.copy()
    not_parsed_queries = {}

    for i, hash in enumerate(specs[db_name]):
        # Need to have a copy of the schema, pk, fk, schema_types because they are modified in the create_table_expression function
        schema = schema_copy.copy()
        pk = pk_copy.copy()
        fk = fk_copy.copy()
        schema_types = schema_types_copy.copy()
        # print("i", i)
        print(specs[db_name][hash])
        print("************ SET OP ************")
        if "set_op_type" not in specs[db_name][hash]:
            spec = specs[db_name][hash]
        elif specs[db_name][hash]["set_op_type"] == "none":
            spec = specs[db_name][hash]["first_query"]
        else:
            spec = specs[db_name][hash]
            print("************ SET OP ************")

            spec1 = specs[db_name][hash]["first_query"]
            spec2 = specs[db_name][hash]["second_query"]
            try:
                first_query = query_generator_single_schema(
                    db_name,
                    schema,
                    pk,
                    fk,
                    schema_types,
                    specs={
                        db_name: {hash: {"set_op_type": "none", "first_query": spec1}}
                    },
                    write_to_csv=False,
                    is_subquery=False,
                    random_choice=True,
                )

                second_query = query_generator_single_schema(
                    db_name,
                    schema,
                    pk,
                    fk,
                    schema_types,
                    specs={
                        db_name: {hash: {"set_op_type": "none", "first_query": spec2}}
                    },
                    write_to_csv=False,
                    is_subquery=False,
                    random_choice=True,
                )
                first_query = list(first_query.values())[0].split("\n")[0]
                second_query = list(second_query.values())[0].split("\n")[0]
                completed_query = f"{first_query} {spec['set_op_type']} {second_query}"
                print("******************COMPLETED QUERY******************")
                print(completed_query)
                if str(spec) in merged_queries:
                    merged_queries[str(spec)] += "\n" + completed_query
                else:
                    merged_queries[str(spec)] = completed_query
                if write_to_csv:
                    write_queries_to_file(
                        merged_queries=merged_queries, db_name=db_name
                    )
            except Exception as e:
                print(e)
                print("Error in SET OP")
                if str(spec) in merged_queries:
                    merged_queries[str(spec)] += "\n" + e
                else:
                    merged_queries[str(spec)] = e

                if testing_with_one_spec:
                    raise e
                continue

            print("Done generating queries")
            continue

        table_exp_type = spec["table_exp_type"]
        where_clause_type = spec["where_type"]
        group_by_clause_type = spec["number_of_value_exp_in_group_by"]
        having_type = spec["having_type"]
        order_by_type = spec["orderby_type"]
        limit_type = spec["limit_type"]
        value_exp_types = spec["value_exp_types"]
        meaningful_joins = spec["meaningful_joins"]
        distinct = spec["distinct_type"]
        min_max_depth_in_subquery = spec["min_max_depth_in_subquery"]
        if is_subquery:
            random_choice = True

        try:
            queries_with_attributes = create_table_expression(
                schema,
                pk,
                fk,
                schema_types,
                table_exp_type,
                meaningful_joins,
                db_name=db_name,
                random_choice=random_choice,
                min_max_depth_in_subquery=min_max_depth_in_subquery,
                query_generator_single_schema_func=query_generator_single_schema,
            )
            random.shuffle(queries_with_attributes)

        except Exception as e:
            print(e)
            print("Error in table expression")
            if str(spec) in merged_queries:
                merged_queries[str(spec)] += "\n" + e
            else:
                merged_queries[str(spec)] = e

            if testing_with_one_spec:
                raise e
            continue

        for query_info in queries_with_attributes:
            partial_query, tables, attributes, cte = query_info
            print("************TABLE EXPRESSION ************\n")
            print_attributes(
                partial_query=partial_query,
                tables=tables,
                attributes=attributes,
                cte=cte,
            )

            try:
                partial_query_with_attributes = complete_with_where_clause(
                    schema,
                    schema_types,
                    db_name,
                    partial_query,
                    attributes,
                    where_clause_type,
                    pk,
                    fk,
                    tables,
                    must_be_in_where,
                    random_choice=random_choice,
                    min_max_depth_in_subquery=min_max_depth_in_subquery,
                    query_generator_single_schema_func=query_generator_single_schema,
                )
                print("************ WHERE ************")
                for partial_query, attributes in partial_query_with_attributes:
                    print("************ WHERE ************")
                    print_attributes(
                        partial_query=partial_query,
                        tables=tables,
                        attributes=attributes,
                    )

                    try:
                        partial_query_with_attributes = complete_with_group_by_clause(
                            partial_query,
                            attributes,
                            tables,
                            pk,
                            group_by_clause_type,
                            random_choice=random_choice,
                        )
                        print("************ GROUP BY ALL ************")
                        for (
                            partial_query,
                            attributes,
                            must_have_attributes,
                        ) in partial_query_with_attributes:
                            print("************ GROUP BY ************")
                            if must_be_in_select is None:
                                must_be_in_select = []
                            temp = must_be_in_select.copy()
                            for attr in must_have_attributes:
                                temp.append(attr)
                            print_attributes(
                                partial_query=partial_query,
                                attributes=attributes,
                                must_be_in_select=temp,
                            )

                            must_be_in_select1 = temp.copy()
                            try:
                                partial_query_with_attributes = complete_with_having_clause(
                                    partial_query,
                                    attributes,
                                    must_be_in_select1,
                                    having_type,
                                    schema,
                                    schema_types,
                                    db_name,
                                    pk,
                                    fk,
                                    tables,
                                    min_max_depth_in_subquery=min_max_depth_in_subquery,
                                    query_generator_single_schema_func=query_generator_single_schema,
                                    random_choice=random_choice,
                                )

                                for (
                                    partial_query,
                                    attributes,
                                    must_be_in_select1,
                                ) in partial_query_with_attributes:
                                    print("************ Having ************")
                                    print_attributes(
                                        partial_query=partial_query,
                                        attributes=attributes,
                                        must_be_in_select=must_be_in_select1,
                                    )

                                    try:
                                        partial_query_with_attributes = complete_query_with_select(
                                            schema,
                                            schema_types,
                                            db_name,
                                            pk,
                                            fk,
                                            tables,
                                            partial_query,
                                            attributes,
                                            must_be_in_select1,
                                            value_exp_types,
                                            distinct,
                                            is_subquery=is_subquery,
                                            random_choice=random_choice,
                                            min_max_depth_in_subquery=min_max_depth_in_subquery,
                                            query_generator_single_schema_func=query_generator_single_schema,
                                            cte=cte,
                                            rename_must_be_in_select=rename_must_be_in_select,
                                        )
                                        print("************ SELECT ************")
                                        for (
                                            partial_query,
                                            attributes,
                                            must_be_in_select1,
                                            select_clause,
                                            num_value_exps,
                                            select_fields_types,
                                        ) in partial_query_with_attributes:
                                            print_attributes(
                                                partial_query=partial_query,
                                                attributes=attributes,
                                                must_be_in_select=must_be_in_select1,
                                                select_clause=select_clause,
                                                num_value_exps=num_value_exps,
                                                select_fields_types=select_fields_types,
                                            )
                                            print("WHY")

                                            partial_query = (
                                                complete_query_with_order_by(
                                                    partial_query,
                                                    attributes,
                                                    select_clause,
                                                    num_value_exps,
                                                    order_by_type,
                                                )
                                            )
                                            print("************ ORDER BY ************")
                                            print_attributes(
                                                partial_query=partial_query
                                            )

                                            partial_query = complete_query_with_limit(
                                                partial_query, limit_type
                                            )
                                            print(
                                                "************ LIMIT & OFFSET ************"
                                            )
                                            print_attributes(
                                                partial_query=partial_query
                                            )
                                            print("************ COMPLETED QUERY ************")

                                            current_dir = os.path.dirname(__file__)

                                            table_file = os.path.abspath(
                                                current_dir + "/../data/tables.json"
                                            )
                                            
                                            # print(db_names)
                                            # print(tables)
                                           
                                            flag = False
                                            db2 = db_name
                                            db2 = os.path.join("test-suite-sql-eval-master/database/", db2, db2 + ".sqlite")
                                            print(db2)
                                            schema2 = Schema3(get_schema(db2))
                                            print(schema2)
                                            print(partial_query)
                                            print(is_subquery)
                                            if not is_subquery:
                                                try:
        
                                                    g_sql = get_sql(schema2, partial_query)

                                                    flag = True
                                                    print(flag)

                                                except AssertionError as e:
                                                    print("Error in Parsing:", e.args)
                                                    if str(spec) in not_parsed_queries:
                                                        not_parsed_queries[
                                                            str(spec)
                                                        ].append((partial_query, e.args))
                                                    else:

                                                        not_parsed_queries[str(spec)] = [
                                                            (partial_query, e.args)
                                                        ]
                                            if is_subquery:
                                                flag = True

                                            if str(spec) in merged_queries and flag:
                                                merged_queries[str(spec)] += (
                                                    "\n\n" + partial_query
                                                )
                                            elif (
                                                str(spec) not in merged_queries and flag
                                            ):
                                                merged_queries[str(spec)] = (
                                                    partial_query
                                                )
                                            if return_select_fields:
                                                return_select_fields_dict[hash] = {
                                                    "select_fields": select_clause
                                                }
                                            if return_table_exp_attributes:
                                                return_select_fields_dict[hash][
                                                    "table_exp_attributes"
                                                ] = {}
                                                return_select_fields_dict[hash][
                                                    "table_exp_attributes"
                                                ] = attributes
                                            if return_unique_tables:
                                                return_select_fields_dict[hash][
                                                    "unique_tables"
                                                ] = tables
                                            if return_select_fields_dict:
                                                return_select_fields_dict[hash][
                                                    "select_fields_types"
                                                ] = select_fields_types
                                    except Exception as e:
                                        print("Error in SELECT")

                                        if str(spec) in merged_queries:
                                            merged_queries[str(spec)] += "\n" + str(e)
                                        else:
                                            merged_queries[str(spec)] = str(e)

                                        if testing_with_one_spec:
                                            raise e
                                        continue

                            except Exception as e:
                                print("Error in HAVING")

                                if str(spec) in merged_queries:
                                    merged_queries[str(spec)] += "\n" + str(e)
                                else:
                                    merged_queries[str(spec)] = str(e)

                                if testing_with_one_spec:
                                    raise e
                                continue

                    except Exception as e:
                        print("Error in GROUP BY")

                        if testing_with_one_spec:
                            raise e
                        continue
            except Exception as e:
                print("Error in WHERE")
                if str(spec) in merged_queries:
                    merged_queries[str(spec)] += "\n" + str(e)
                else:
                    merged_queries[str(spec)] = str(e)

                if testing_with_one_spec:
                    raise e
                continue

    if write_to_csv:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        parent_dir = os.path.dirname(current_dir)
        output_dir = os.path.abspath(os.path.join(parent_dir, "data/synthetic-queries/rule-based/"))
        csv_file = os.path.join(output_dir, f"{db_name}_res.csv")
        write_queries_to_file(
            merged_queries=merged_queries, db_name=db_name, file_name=csv_file
        )
        current_dir = os.path.dirname(__file__)
        output_dir = os.path.abspath(os.path.join(current_dir, "output/errors/"))
        error_csv_file = os.path.join(output_dir, f"parsing_error_{db_name}_res.csv")
        write_queries_to_file(
            merged_queries=not_parsed_queries,
            db_name=db_name,
            file_name=error_csv_file,
        )

    print("Done generating queries")
    if return_select_fields:
        return merged_queries, return_select_fields_dict
    return merged_queries


def query_generator(
    db_name=None,
    specs=None,
    max_num=1000,
    config_name="config_file.json",
    write_to_csv=True,
    random_choice=False,
    n_dbs=None,
):
    current_dir = os.path.dirname(__file__)
    db_file = os.path.join(current_dir, "../data/tables.json")
    all_db = convert_json_to_schema(db_file)
    current_dir = os.path.dirname(__file__)
    config_file = os.path.abspath(os.path.join(current_dir, config_name))
    if n_dbs is None:
        n_dbs = len(all_db)
    if db_name is None:
        # randomly select:
        random_dbs = random.sample(list(all_db.keys()), n_dbs)
        # call query_generator_single_schema for all databases
        for db in random_dbs:
            schema, pk, fk, schema_types = read_schema_pk_fk_types(
                db, db_file, all_db=all_db
            )
            complete_specs(
                db_file,
                config_file,
                db_name=db,
                num_query=max_num,
            )
            print("DONEEEEEEEEE_________________________________-")
            try:
                query_generator_single_schema(
                    db,
                    schema,
                    pk,
                    fk,
                    schema_types,
                    specs=specs,
                    max_num=20,
                    write_to_csv=True,
                    random_choice=random_choice,
                )
            except Exception as e:
                print(e)
    else:
        # call query_generator_single_schema for the given database
        schema, pk, fk, schema_types = read_schema_pk_fk_types(
            db_name, db_file, all_db=all_db
        )
        # print("NEF1")
        complete_specs(
            db_file,
            config_file,
            db_name=db_name,
            num_query=max_num,
        )
        # print("NEF")

        try:
            query_generator_single_schema(
                db_name,
                schema,
                pk,
                fk,
                schema_types,
                specs=specs,
                max_num=max_num,
                write_to_csv=True,
                random_choice=random_choice,
            )
        except Exception as e:
            print(e)

def evaluate_query(query, db_name, schema, specification):
        # using llm to check the query
        pass



 

def make_request(messages,client, model_name):
        response = client.chat.completions.create(
            model=model_name,
            messages=messages,
            max_tokens=512,
    )
        good_json_string = repair_json(response.choices[0].message.content,return_objects=True)
        return good_json_string
def query_generator_single_schema_llm(client,model_name, db_name, schema, pk, fk, schema_types,all_db, specs, max_num=20, write_to_csv=True, random_choice=True):        
    print(all_db["behavior_monitoring"])
    CONSTRUCT_SQL_MSGS =[
    {
        "role": "system",
        "content": "You are an SQL query generator. Your task is to generate an SQLite query based on the given specification. Follow the specification details closely to construct a valid and accurate query. The specification includes schema details, primary keys (PK), and foreign keys (FK) and column types. The output should be in JSON format with a key 'query'."
    },
    {
        "role": "user",
        "content": f"""{{"spec": {{"meaningful_joins": "yes", "table_exp_type": "single_table", "where_type": "none", "number_of_value_exp_in_group_by": 0, "having_type": "none", "orderby_type": "DESC", "limit_type": "none", "value_exp_types": "*", "distinct_type": "none", "min_max_depth_in_subquery": [1, 1]}}, "schema": {all_db["behavior_monitoring"]["schema"]}, "pk": {all_db["behavior_monitoring"]["primary_keys"]}, "fk": {all_db["behavior_monitoring"]["foreign_keys"]}, "column_types": {all_db["behavior_monitoring"]["schema_types"]}}}"""
    },{
        "role": "assistant",
        "content": "{\"query\": \"SELECT *  FROM Ref_Incident_Type ORDER BY incident_type_code DESC\"}"
    },
    
]
    print("Start reading specifications")
    testing_with_one_spec = False
    if specs is not None:
        testing_with_one_spec = True
    if not testing_with_one_spec:
        print("Testing with multiple specifications")
        current_dir = os.path.dirname(__file__)
        file_name = os.path.join(current_dir, f"output/specs/{db_name}.json")
        with open(file_name) as json_file:
            specs = json.load(json_file)
    else:
        print("Testing with one specification")
        print(specs)

    print("Start generating queries")
    merged_queries = {}
    return_select_fields_dict = {}
    schema_copy = schema.copy()
    pk_copy = pk.copy()
    fk_copy = fk.copy()
    schema_types_copy = schema_types.copy()
    not_parsed_queries = {}

    for i, hash in enumerate(specs[db_name]):
        # Need to have a copy of the schema, pk, fk, schema_types because they are modified in the create_table_expression function
        schema = schema_copy.copy()
        pk = pk_copy.copy()
        fk = fk_copy.copy()
        schema_types = schema_types_copy.copy()
        # print("i", i)
        # print(specs[db_name][hash])
        CONSTRUCT_SQL_MSGS.append(
            { "role": "user",
            "content": f"""{{"spec":{specs[db_name][hash]}, "schema": {schema},"pk": {pk} ,"fk": {fk}, "column_types": {schema_types}}}"""    }
        )
        res = make_request(CONSTRUCT_SQL_MSGS,client, model_name)
        # print(res["query"])
            
            

def generate_query_using_llm(max_num, random_choice, config_name, n_dbs,db_name=None, specs=None, write_to_csv=False ):
        current_dir = os.path.dirname(__file__)
        db_file = os.path.join(current_dir, "../data/tables.json")
        current_dir = os.path.dirname(__file__)
        all_db = convert_json_to_schema("data/tables.json", col_exp=False)

        config_file = os.path.abspath(os.path.join(current_dir, config_name))
        client = OpenAI(
        api_key="token-wdmuofa",
        base_url="http://anagram.cs.ualberta.ca:2000/v1" # Choose one from the table
        # base_url = "http://turin4.cs.ualberta.ca:2001/v1"
        
    )
     
        model_name = "meta-llama/Meta-Llama-3-70B-Instruct" # Choose one fro
    
    

        if db_name is None:
            # randomly select:
            random_dbs = random.sample(list(all_db.keys()), n_dbs)
            # call query_generator_single_schema for all databases
            for db in random_dbs:
                schema, pk, fk, schema_types = read_schema_pk_fk_types(db, db_file, all_db=all_db, col_exp=False)
                complete_specs(db_file, config_file, db_name=db, num_query=max_num)
                try:
                    query_generator_single_schema_llm(client,model_name,db, schema, pk, fk, schema_types,all_db, specs=specs, max_num=max_num, write_to_csv=True, random_choice=random_choice)
                except Exception as e:
                    print(e)
        else:
            # call query_generator_single_schema for the given database
            schema, pk, fk, schema_types = read_schema_pk_fk_types(db_name, db_file, all_db=all_db)
            complete_specs(db_file, config_file, db_name=db_name, num_query=max_num)
            try:
                query_generator_single_schema_llm(client,model_name,db_name, schema, pk, fk, schema_types,all_db, specs=specs, max_num=max_num, write_to_csv=True, random_choice=random_choice)
            except Exception as e:
                print(e)

        
def query_generator_with_llm_refinement(folder_path = "data/synthetic-queries/Schema_guided/"):
    # concat_all(folder_path)
    # folder_path = "data/synthetic-queries/Rule-based/"
        # concat_all(folder_path)
        # file = "data/synthetic-queries/Rule-based/rule-based-synthsql.csv"

    FEEDBACK_GENERATOR_MSGS = [
    {
        "role": "system",
        "content": "You are an SQL query evaluator. Your task is to evaluate the given SQL query based on the provided schema information, which includes details such as schema structure, primary keys (pk), foreign keys (fk), and column types. Assess the query for correctness, logical validity, and alignment with the schema structure. Provide feedback in JSON format under the key 'feedback'. If the query is correct and valid, return {'feedback': 'valid'}. Otherwise, provide specific, constructive feedback highlighting any issues, such as syntax errors, incorrect column references, or logical inconsistencies."
    }
]
    REFINE_MSGS = [
    {
        "role": "system",
        "content": "You are an SQL query refiner. Your task is to improve the given SQL query based on provided feedback and schema details, including schema structure, primary keys (pk), foreign keys (fk), and column types. Modify the query to ensure correctness, logical consistency, and alignment with the schema. Return the refined query in JSON format with the key 'refined_query'."
    }
]
    current_dir = os.path.dirname(__file__)
    db_file = os.path.join(current_dir, "../data/tables.json")
    current_dir = os.path.dirname(__file__)
    all_db = convert_json_to_schema("data/tables.json", col_exp=False)


    

    # for i, hash in enumerate(specs[db_name]):
    #     # Need to have a copy of the schema, pk, fk, schema_types because they are modified in the create_table_expression function
    #     schema = schema_copy.copy()
    #     pk = pk_copy.copy()
    #     fk = fk_copy.copy()
    #     schema_types = schema_types_copy.copy()
    #     # print("i", i)
    #     # print(specs[db_name][hash])
    #     CONSTRUCT_SQL_MSGS.append(
    #         {
    #     "role": "user",
    #     "content":"Give feedback on the following query: {query},\n based on the schema-guided info: {schema}, {pk}, {fk}, {column_types}" 
    # }
    #     res = make_request(CONSTRUCT_SQL_MSGS,client, model_name)
    
    client = OpenAI(
        api_key="token-wdmuofa",
        base_url="http://anagram.cs.ualberta.ca:2000/v1" # Choose one from the table
        # base_url = "http://turin4.cs.ualberta.ca:2001/v1"
        
    )
     
    model_name = "meta-llama/Meta-Llama-3-70B-Instruct" # Choose one fro
    

    for file in glob.glob(os.path.join(folder_path, '*.csv')):
        

        db_name = os.path.basename(file).split("_res.csv")[0]

        # statistics[db_name] = hardness_levels.copy()
        df = pd.read_csv(file)

        for instance in df.to_dict(orient="records"):
            schema = all_db[db_name]["schema"]
            pk = all_db[db_name]["primary_keys"]
            fk = all_db[db_name]["foreign_keys"]
            col_types = all_db[db_name]["schema_types"]

            FEEDBACK_GENERATOR_MSGS.append(
                    {
                "role": "user",
              "content":"Give feedback on the following query: {query},\n based on the schema-guided info: {schema}, {pk}, {fk}, {column_types}" 
            })
            print("hi")
            res = make_request(FEEDBACK_GENERATOR_MSGS,client, model_name)
            print(res)
            break
        break
    
            

            # print(

    


if __name__ == "__main__":
    specs = {
        "advertising_agencies": {
            "ae99efea2cbadfa5e336d8fd2a4fd91b0911f8b8": {
                            "set_op_type": "none",
                            "first_query": {
'meaningful_joins': 'yes', 'table_exp_type': 'JOIN', 'where_type': {'logical_operator': ['OR', 'basic_comparison', 'exists_subquery']}, 'number_of_value_exp_in_group_by': 0, 'having_type': 'none', 'orderby_type': 'ASC', 'limit_type': 'none', 'value_exp_types': ['agg_exp', 'agg_exp', 'single_exp_text'], 'distinct_type': 'none', 'min_max_depth_in_subquery': [1, 1]}
            }
        }
    }
    # }
    



    # generate_query_using_llm(
    #     # db_name="movie_1",
    #     # specs=specs,
    #     max_num=20,
    #     write_to_csv=False,
    #     random_choice=True,
    #     config_name="config_file.json",
    #     # n_dbs = 5
    # )

    ######################Schema-guided query generation######################
    # query_generator(
    #     # db_name="advertising_agencies",
    #     # specs=specs,
    #     max_num=60,

    #     write_to_csv=True,
    #     random_choice=True,
    #     config_name="config_file.json",
    # )
    ######################Schema-guided + LLM Refinement query generation######################
    query_generator_with_llm_refinement()